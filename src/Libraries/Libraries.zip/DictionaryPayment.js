/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _pembayaran = ["Pembayaran", "Payment"];
export const _discount_promo = ["Special Promo", "Special Promo"];

export const _voucher = ["Voucher Promo", "Voucher Promo"];

export const _cash = ["Kas", "Cash"];
export const _card = ["Kartu", "Card"];
export const _ewallet = ["E-Wallet", "E-Wallet"];
export const _cash_amount = ["Jumlah Kas", "Cash Amount"];

export const _exclude_tax = ["Diluar Pajak", "Exclude Tax"];

export const _kembali = ["Kembali", "Back"];

export const _batal = ["Batal", "Cancel"];

export const _include_tax = ["Termasuk Pajak", "Include Tax"];

export const _sukses = ["Sukses", "Success"];

export const _gagal = ["Proses Gagal", "Process Failed"];


export const _paid_by = ["Pembayaran dengan", "Paid by"];

export const _change_amount = ["Jumlah Kembali", "Change Amount"];

export const _no_change = ["Tidak ada Kembali", "No Change"];

export const _terima_kasih = ["Terima Kasih", "Thank You"];

export const _kirim_ke = ["Kirim Struk Ke Email", "Send Receipt To Email"];

export const _nama_pelanggan = ["Nama Pelanggan", "Customer Name"];

export const _kirim_whats_app = ["Kirim Struk Ke WhatsApp", "Send Receipt to Whats app"];

export const _daftarkan_pelanggan = ["Daftarkan Pelanggan", "Register Customer"];

export const _kirim_struk_online = ["Kirim Struk Online", "Send Receipt Online"];

export const _cetak_struk_dapur = ["Cetak Struk Dapur", "Print Kitchen"];

export const _penilaian_pelanggan = ["Penilaian Pelanggan", "Customer Rating"];

export const _rate_staff = ["Nilai Staff", "Rate Staff"];
export const _rate_food = ["Nilai Makanan", "Rate Food"];


export const _rate_1 = ["Sangat Buruk", "Terrible"];
export const _rate_2 = ["Buruk", "Bad"];
export const _rate_3 = ["Netral", "Average"];
export const _rate_4 = ["Baik", "Good"];
export const _rate_5 = ["Sangat Baik", "Excellent"];


export const _print_receipt = ["Print Struk", "Print Receipt"];
export const _simpan = ["Simpan", "Save"];

export const _points_used = ["Point Digunakan", "Points Used"];

export const _use_points = ["Gunakan Point" , "Use Points"];

export const _promo = ["Promo" , "Promo"];


export const _alert_kurang = [
  "Jumlah pembayaran tidak valid atau kurang",
  "Amount of payment is not valid or not enough"
];
