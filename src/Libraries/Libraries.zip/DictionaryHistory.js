/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _riwayat_transaksi = ["Riwayat Transaksi", "Transaction History"];

export const _cari = ["Cari", "Search"];

export const _today = ["Hari Ini", "Today"];

export const _this_week = ["Minggu Ini", "This Week"];

export const _this_month = ["Bulan Ini", "This Month"];

export const _this_year = ["Tahun Ini", "This Year"];

export const _from = ["Dari", "From"];

export const _to = ["Sampai", "To"];

export const _transaction_id = ["ID Transaksi", "Transaction ID"];

export const _total_price = ["Total Harga", "Total Price"];

export const _payment_type = ["Pembayaran", "Payment Type"];

export const _time = ["Waktu", "Time"];

export const _merchant = ["Gerai", "Merchant"];

export const _receipt_number = ["Kode Struk", "Receipt Number"];

export const _time_date = ["Waktu & Tanggal", "Time & Date"];

export const _send_receipt = ["Kirim Struk", "Send Receipt"];

export const _reprint_receipt = ["Reprint Struk", "Reprint Receipt"];

export const _issue_refund = ["Refund", "Issue Refund"];

export const _cancel = ["Kembali", "Cancel"];

export const _enter = ["Lanjut", "Enter"];

export const _alert_printer = [
  "Printer tidak terdeteksi. Silahkan setting printer terlebih dahulu untuk mengakses halaman ini.",
  "Printer Not Detected."
];

export const _notes = ["Catatan: ", "Notes: "];
export const _status_1 = ["Transaksi Baru", "New Transaction"];

export const _status_2 = ["Transaksi Dikembalikan", "Transaction Refunded"];

export const _status_3 = ["Transaksi Dibatalkan", "Transaction Cancelled"];

export const _status_4 = ["Transaksi Selesai", "Transaction Done"];

export const _status_5 = ["Transaksi Ditutup", "Transaction Closed"];

export const _detail_pesanan = ["Detail Pesanan", "Order Detail"];

//[this.state.languageIndex]

export const _pilih_user = ["Pilih User", "Choose User"];

export const _pajak = ["Tax", "Tax"];
export const _service = ["Service", "Service"];

export const _detail_transaksi = ["Detail Transaksi", "Transaction Detail"];

export const _batalkan_transaksi = ["Batalkan Transaksi", "Cancel Transaction"];

export const _other_reason = ["Lain - lain", "Other Reason"];

export const _tulis_alasan = ["Tulis Alasan", "Insert Reason"];

export const _simpan = ["Simpan", "Save"];

export const _reason_1 = ["Produk Habis", "Product not available"];
export const _reason_2 = ["Kesalahan Input", "Wrong Input"];
export const _reason_3 = ["Permintaan Pelanggan", "Customer's Request"];
export const _masukan_kode = [
  "Masukan Kode Otorisasi untuk membatalkan",
  "Insert Authorization Code to continue"
];

export const _salah_pin = ["Pin salah.", "Pin does not match."];

export const _berhasil = ["Berhasil update data.", "Update data success."];
export const _set_filter = ["Tentukan Pencarian", "Set Filter"];

export const _by_status = ["Berdasarkan Status", "By Transaction Status"];
export const _by_payment = ["Berdasarkan Pembayaran", "By Payment Type"];

export const _by_code = ["Berdasarkan Kode", "By Code"];

export const _status_filter_1 = ["Semua Status", "All Status"];
export const _status_filter_2 = ["Sukses", "Success"];
export const _status_filter_3 = ["Void", "Void"];

export const _payment_filter_1 = ["Semua", "All"];
export const _payment_filter_2 = ["Kas", "Cash"];
export const _payment_filter_3 = ["E-Wallet", "E-Wallet"];
export const _payment_filter_4 = ["Kartu", "Card"];
export const _payment_filter_5 = ["Lainnya", "Others"];

export const _refund_stock = ["Kembalikan Stok", "Stock Refund"];
