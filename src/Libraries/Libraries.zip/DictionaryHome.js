/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _cari = ["Cari", "Search"];

export const _cancel = ["Batal", "Cancel"];

export const _next = ["Lanjut", "Next"];

export const _pilih = ["Pilih Satu", "Choose One"];

export const _qty_long = ["Jumlah", "Quantity"];

export const _qty_short = ["Jum", "Qty"];

export const _catatan = ["Catatan", "Notes"];

export const _catatan_extra = ["Isi Bila Diperlukan", "Fill If Needed"];

export const _menu_favorit = ["Menu Favorit", "Favorite Menu"];

export const _semua_menu = ["Semua Menu", "All Menu"];

export const _cetak_bill = ["Cetak Bill", "Print Bill"];

export const _cetak_dapur = ["Cetak Dapur", "Print Kitchen"];

export const _alert_printer = [
  "Printer tidak terdeteksi. Silahkan setting printer terlebih dahulu untuk mengakses halaman ini.",
  "Printer Not Detected."
];

export const _order = ["Order", "Order"];
export const _nama = ["Nama", "Name"];
export const _meja = ["Meja", "Table"];
export const _data_pelanggan = ["Data Pelanggan", "Customer Data"];

export const _berhasil_tambah = ["Berhasil menambah data", "Add data success"];
export const _berhasil_update = ["Berhasil update data", "Update data success"];
export const _berhasil_delete = [
  "Berhasil menghapus data",
  "Delete data success"
];

export const _gagal = ["Gagal proses data", "Failed process data"];

export const _error_1 = ["Tidak ada meja yang tersedia", "No available table"];

export const _error_2 = ["Pesanan tidak boleh kosong", "Order can't be empty"];

export const _error_3 = ["Tidak ada meja yang tersedia", "No available table"];

export const _menu_favorit_short = ["Favorit", "Favorite"];

export const _menu_all_short = ["Semua", "All"];


export const _pajak = ["Pajak", "Tax"];

export const _service = ["Service", "Service"];

export const _lanjut = ["Lanjutkan ke Pembayaran", "Continue to Payment"];

export const _keranjang = ["Keranjang", "Cart"];

export const _pesanan_baru = ["Pesanan Baru", "New Order"];

export const _simpan = ["Simpan", "Save"];
export const _kembali = ["Kembali", "Return"];

export const _harga_custom = ["Harga Custom", "Custom Price"];
export const _simpan_pesanan = ["Simpan Pesanan", "Save Order"];
export const _pelanggan = ["Pelanggan", "Customer"];

export const _pilih_pelanggan = ["Pilih Pelanggan", "Choose Customer"];


export const _clear_cart = ["Bersihkan Keranjang", "Clear Cart"];

export const _transaction_id = ["ID Transaksi", "Transaction ID"];
export const _ubah_harga = ["Ubah Harga", "Change Price"];

export const _no_table = ["No Table", "No Table"];
export const _cashier = ["Cashier", "Cashier"];
