/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu

export const _kas = ["Kas", "Cash"];

export const _cari = ["Cari", "Search"];

export const _today = ["Hari Ini", "Today"];

export const _from = ["Dari", "From"];

export const _to = ["Sampai", "To"];

export const _kasir = ["Kasir", "Cashier"];

export const _alert_printer = [
  "Printer tidak terdeteksi. Silahkan setting printer terlebih dahulu untuk mengakses halaman ini.",
  "Printer Not Detected."
];

export const _user = ["User", "User"];
export const _status = ["Status", "Status"];

export const _status_kas = ["Status Kas", "Cash Status"];

export const _jam = ["Waktu", "Time"];

export const _no_data_1 = ["Belum ada kas masuk / keluar", "No Data Found"];
export const _no_data_2 = [
  "Anda belum memasukan data kas masuk / keluar",
  "You have not insert Cash In/Cash Out data"
];

export const _no_data_3 = [
  "Tidak ada data",
  "No Data"
];

export const _lihat_detail = ["Lihat Detail", "View Detail"];

export const _add = ["Kas Masuk/Keluar", "Add Data"];

export const _add_2 = ["Tambah Kas Masuk/Keluar", "Add Data"];

export const _rekap = ["Rekap Kas", "Recap Cash"];

export const _cash_in = ["Kas Masuk", "Cash In"];

export const _cash_out = ["Kas Keluar", "Cash Out"];

export const _cash_in_out = ["Kas Masuk & Keluar", "Cash In & Out"];

export const _jumlah = ["Jumlah", "Amount"];

export const _catatan = ["Catatan", "Notes"];

export const _simpan = ["Simpan", "Save"];

export const _kembali = ["Kembali", "Back"];

export const _cetak_struk = ["Cetak Struk", "Print Receipt"];

export const _tipe = ["Tipe", "Type"];

export const _penjualan = ["Penjualan", "Sales"];

export const _void = ["Void", "Void"];
export const _cicilan = ["Penerimaan Cicilan", "Credit In"];
export const _jumlah_sistem = ["Jumlah Sistem", "System Total"];

export const _jumlah_transaksi = ["Jumlah Transaksi", "Transaction Total"];


export const _jumlah_aktual = ["Jumlah Aktual", "Actual Total"];
export const _tunai = ["Tunai", "Cash"];
export const _e_wallet = ["E-Wallet", "E-Wallet"];
export const _card = ["Debit/Credit", "Debit/Credit"];


export const _selisih_1 = ["Selisih", "Difference"];

export const _selisih_2 = [
  "Jumlah Aktual - Jumlah Sistem",
  "Actual Total - System Total"
];

export const _berhasil_tambah = ["Berhasil menambah data", "Add data success"];
export const _berhasil_update = ["Berhasil update data", "Update data success"];
export const _berhasil_delete = [
  "Berhasil menghapus data",
  "Delete data success"
];

export const _gagal = ["Gagal proses data", "Failed process data"];

export const _error_semua_field = [
  "Semua Field harus diisi",
  "All field must be filled"
];

export const _pilih_user = ["Pilih User", "Choose User"];

export const _this_week = ["Minggu Ini", "This Week"];

export const _this_month = ["Bulan Ini", "This Month"];

export const _this_year = ["Tahun Ini", "This Year"];

export const _cetak_struk_1 = ["Cetak Detail Kas", "Print Detail"];
