/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _manajemen_meja = ["Manajemen Meja", "Table Management"];

export const _action_0 = ["Aksi", "Action"];

export const _action_1 = ["Pilih Meja", "Choose Table"];

export const _action_2 = ["Gabung/Pisah Meja", "Combine/Split Table"];

//

export const _kode = ["Kode", "Code"];

export const _notifikasi = ["Notifikasi", "Notification"];

export const _booking = ["Booking", "Booking"];

export const _tolak = ["Tolak", "Reject"];

export const _hold = ["Hold", "Hold"];

export const _konfirmasi = ["Konfirmasi", "Confirm"];

export const _permintaan_reservasi = [
  "Permintaan Reservasi",
  "Reservation Request"
];

export const _message_1 = [
  "mengirim permintaan reservasi melalui Beet Apps.",
  "has send a reservation request using Beet Apps."
];

export const _message_2 = [
  "Reservasi oleh pelanggan",
  "Reservation by Customer"
];

export const _status_1 = ["Tersedia", "Available"];
export const _status_2 = ["Direservasi", "Reserved"];
export const _status_3 = ["Digunakan", "Used"];
export const _customer_name = ["Nama Customer", "Customer Name"];

export const _notes = ["Catatan", "Notes"];

export const _cetak_bill = ["Cetak Bill", "Print Bill"];

export const _check_in_time = ["Waktu Check In", "Check In Time"];
export const _reserved_time = ["Waktu Reservasi", "Reserved Time"];

export const _pindah_meja = ["Pindah Meja", "Move Table"];

export const _gabung_pisah_transaksi = [
  "Gabung / Pisah Transaksi",
  "Combine or Separate Transaction"
];

export const _batal = ["Batal", "Cancel"];
export const _kembali = ["Kembali", "Back"];

export const _nama = ["Nama", "Name"];
export const _jumlah = ["Jumlah", "Qty"];

//_status_1[this.state.languageIndex]

export const _pindahkan_semua = ["Pindahkan Semua", "Move All"];
export const _proses_perpindahan = ["Proses Perpindahan", "Process Move"];

export const _pindahkan = ["Pindahkan", "Move"];

export const _pindahkan_produk = ["Pindahkan Produk", "Move Product"];

export const _gagal_proses = [
  "Gagal memperoses data karena: ",
  "Failed to process data because:"
];

export const _reason_failed_1 = [
  "Meja tidak tersedia.",
  "Table is not available."
];

export const _reason_failed_2 = [
  "Kapasitas meja tidak cukup.",
  "Table capacity is not enough"
];

export const _reason_failed_3 = [
  "Meja tidak tersedia.",
  "Table is not available."
];

export const _success = ["Order berhasil diupdate", "Success to update Order"];

export const _failed = ["Order gagal diupdate", "Failed to update Order"];

export const _success_order = [
  "Konfirmasi booking berhasil",
  "Booking Confirmation Success"
];

export const _cari = ["Cari No Meja", "Search Table"];
