/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _aplikasi = ["Aplikasi", "Application"];

export const _printer = ["Printer", "Printer"];

export const _management_printer = ["Manajemen Printer", "Printer Management"];

export const _print_2 = ["Print Sekaligus", "Simultant Print"];


export const _struk = ["Struk", "Receipt"];

export const _lain = ["Lainnya", "Others"];

export const _informasi = ["Informasi", "Information"];

export const _logout = ["Log Out", "Log Out"];

//printer

export const _auto_detect_printer = [
  "Deteksi Otomatis Printer",
  "Auto Detect Printer"
];

export const _perangkat_printer_terdeteksi = [
  "Perangkat Printer Terdeteksi",
  "Printer Detected"
];

export const _bluetooth_tidak_aktif = [
  "Bluetooth tidak aktif",
  "Bluetooth not active"
];

export const _bluetooth_tidak_aktif_2 = [
  "Bluetooth tidak bisa aktif",
  "Bluetooth can't be activated"
];

export const _perangkat_printer_tidak_terdeteksi = [
  "Printer tidak terhubung dengan perangkat",
  "Printer Not Detected"
];

export const _dapur = ["Dapur", "Kitchen"];

export const _cashier = ["Kasir", "Cashier"];

//aplikasi
export const _pilih_bahasa = ["Pilih Bahasa", "Choose Language"];

export const _warna_aplikasi = ["Warna Aplikasi", "Application Color"];

export const _backup_data = ["Backup Data", "Backup Data"];

export const _show_stock = ["Tampilkan Stok", "Show Stock"];


export const _sinkronisasi_data = ["Sinkronisasi Data", "Sync Data"];

//struk
export const _edit_footer = ["Edit Footer Struk", "Edit Receipt Footer"];

export const _upload_logo = ["Upload Logo Struk", "Upload Receipt Logo"];

export const _cetak_order_id = ["Cetak Order Id", "Print Order Id"];

export const _catat_saldo = ["Catat Saldo Rekap Kas", "Save Recap Value"];

export const _tampilkan_stok = ["Tampilkan Stok di Menu", "Show Stock In Menu"];

//info

export const _nama_perangkat = ["Nama Perangkat", "Device Name"];

export const _tipe_account = ["Tipe Account", "Account Type"];

export const _alamat_ip = ["Alamat IP", "IP Address"];

export const _versi = ["Versi", "Version"];

export const _sukses_footer = [
  "Sukses Set Footer Printer",
  "Edit Footer success"
];

export const _sukses_printer_1 = ["Sukses Set Printer", "Printer Set"];

export const _sukses_printer_2 = [
  "Sukses Set Printer Dapur",
  "Kitchen Printer Set"
];

export const _cari = ["Cari pengaturan...", "Search settings..."];

export const _edit = ["Ubah", "Edit"];

export const _tidak_aktif = ["Tidak Aktif", "Not Active"];

export const _aktif = ["Aktif", "Active"];
