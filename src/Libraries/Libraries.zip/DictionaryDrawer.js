/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _transaksi = ["Transaksi", "Transaction"];

export const _riwayat = ["Riwayat Transaksi", "Transaction History"];

export const _absensi = ["Absensi", "Attendance"];

export const _management = ["Manajemen Pelanggan", "Customer Management"];

export const _rekap = ["Rekap Kas", "Recap Cash"];

export const _pengaturan = ["Pengaturan", "Settings"];

//

export const _notifikasi = ["Notifikasi", "Notification"];

export const _booking = ["Booking", "Booking"];

export const _tolak = ["Tolak", "Reject"];

export const _hold = ["Hold", "Hold"];

export const _konfirmasi = ["Konfirmasi", "Confirm"];

export const _permintaan_reservasi = [
  "Permintaan Reservasi",
  "Reservation Request"
];

export const _message1 = [
  "mengirim permintaan reservasi melalui Beet Apps.",
  "has send a reservation request using Beet Apps."
];

export const _message2 = [
  "Reservasi oleh pelanggan",
  "Reservation by Customer"
];

export const _nama = ["Nama", "Name"];
export const _jumlah = ["Jumlah Pax", "Person Number"];
export const _waktu = ["Waktu Reservasi", "Reservation Time"];
export const _date = ["Tanggal Reservasi", "Reservation Date"];
export const _notes = ["Catatan", "Notes"];
export const _status = ["Status Reservasi:", "Reservation Status:"];
export const _time_left = ["Waktu Tersisa:", "Time Left:"];
