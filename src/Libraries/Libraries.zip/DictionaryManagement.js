/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _data_pelanggan = ["Data Pelanggan", "Customer Data"];

export const _nama = ["Nama", "Name"];

export const _email = ["Email", "Email"];

export const _phone = ["No. HP", "Phone"];

export const _search = ["Cari data pelanggan", "Search"];

export const _total_transaksi = ["Total Transaksi", "Transaction Total"];
export const _jumlah_poin = ["Jumlah Poin", "Points"];
export const _phone_long = ["Nomor Handphone", "Phone Number"];
export const _alamat = ["Alamat", "Address"];
export const _catatan = ["Catatan", "Notes"];
export const _catatan_extra = ["Isi Bila Diperlukan", "Fill If Needed"];

export const _catatan_kosong = ["Tidak ada catatan khusus", "No special notes"];

export const _cancel = ["Kembali", "Cancel"];

export const _simpan = ["Simpan", "Save"];

export const _ubah = ["Ubah", "Edit"];

export const _delete = ["Hapus", "Delete"];


export const _riwayat = ["Riwayat Transaksi Pelanggan", "Customer Transaction History"];


export const _tambah = ["Tambah", "Add"];

export const _kembali = ["Kembali", "Back"];

export const _berhasil_tambah = ["Berhasil menambah data", "Add data success"];
export const _berhasil_update = ["Berhasil update data", "Update data success"];
export const _berhasil_delete = [
  "Berhasil menghapus data",
  "Delete data success"
];

export const _gagal = ["Gagal proses data", "Failed process data"];

export const _error_semua_field = [
  "Semua Field harus diisi",
  "All field must be filled"
];

export const _fill_1 = ["Nama harus diisi", "Name must be filled"];
export const _fill_2 = ["Email harus diisi", "Email must be filled"];
export const _fill_3 = ["No Hp harus diisi", "Phone must be filled"];
export const _fill_4 = ["Password harus diisi", "Password must be filled"];

export const _view = ["Lihat", "View"];

export const _informasi_kontak = ["Informasi Kontak", "Contact Information"];
