/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _absensi = ["Absensi", "Attendance"];

export const _pilih_user = ["Pilih User", "Choose User"];

export const _masuk = ["Datang", "In"];

export const _pulang = ["Pulang", "Out"];

export const _check_in = ["Datang", "Check In"];

export const _check_out = ["Pulang", "Check Out"];

export const _salah_pin = ["Pin salah.", "Pin does not match."];

export const _berhasil = ["Berhasil update data.", "Update data success."];

export const _gagal = ["Gagal update data.", "Update data failed."];


export const _masukan_kode = [
  "Masukan Kode Otorisasi untuk melanjutkan",
  "Insert Authorization Code to continue"
];
