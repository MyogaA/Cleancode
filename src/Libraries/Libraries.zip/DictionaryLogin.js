/* eslint-disable quotes */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable comma-dangle */

//main menu
export const _remember_me = ["Ingat Saya", "Remember Me"];

export const _title = ["Menu Utama", "Main Menu"];

export const _login = ["Masuk", "Log In"];

export const _lupa_password = ["Lupa Password", "Forgot Password"];

export const _new_to_beetpos = ["Pengguna baru?", "New to BeetPOS?"];

export const _sign_up_now = ["Daftar Sekarang!", "Sign Up Now!"];

export const _register = ["Daftar", "Register"];

export const _name = ["Nama", "Name"];

export const _daftar_gratis = ["Daftar Gratis", "Register Now"];

export const _sudah = ["Sudah memiliki akun?", "Already have account?"];

export const _sign_in_here = ["Sign in disini!", "Sign in here!"];

export const _register_to = ["Daftar Ke", "Register to"];
export const _register_to2 = [
  "Daftar & Dapatkan Masa Percobaan Gratis. Tidak perlu ada Pra-bayar dan Tidak memerlukan Kartu Kredit",
  "Sign Up & Get Free Trial. No Pre-payment and Credit Card needed."
];

export const _register_1 = ["Daftarkan bisnis anda", "Register your business"];

export const _masuk_1 = ["Masuk ke akun anda", "Log in to your account"];
export const _masuk_btn = ["Masuk", "Log In"];
export const _sign_up_now_2 = ["Belum punya akun?", "New user?"];

export const _hello = ["Halo, ", "Hello, "];

export const _menu_1 = ["Pesanan Baru", "New Order"];
export const _menu_2 = ["Riwayat", "History"];
export const _menu_3 = ["Pelanggan", "Customer"];
export const _menu_4 = ["Absensi", "Attendance"];
export const _menu_5 = ["Kas", "Cash"];
export const _menu_6 = ["Pengaturan", "Settings"];
export const _menu_7 = ["Meja", "Table"];

export const _informasi = ["Informasi", "Information"];

export const _pos = ["Point of Sale", "Point of Sale"];
export const _pengaturan = ["Pengaturan & Lainnya", "Settings & Others"];

export const _lupa_password_text = [
  "Masukan Email anda yang terdaftar dalam Beetpos. Kami akan mengirimkan pesan Email yang berisi tautan untuk reset password anda.",
  "Input registered Email. We will send Email that contains the link to reset your password."
];

export const _lupa_password_button = ["Ganti Password", "Change Password"];

export const _page2_1 = ["Selamat Datang di BEETPOS", "Welcome to BEETPOS"];

export const _page2_2 = [
  "Lengkapi Informasi Bisnis Anda",
  "Complete your Business Information"
];


export const _role = ["Role", "Role"];

export const _check_in = ["Waktu Check In", "Check In Time"];

export const _check_out = ["Waktu Check Out", "Check Out Time"];

export const _status_kas = ["Status Kas", "Cash Status"];


